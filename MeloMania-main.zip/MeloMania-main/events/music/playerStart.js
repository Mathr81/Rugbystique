module.exports = {
    name: "playerStart",
    async run(client, queue, track) {
        await queue.metadata.channel.send(`The music [\`${track.title}\`](${track.url}) by \`${track.author}\`, during \`${track.duration}\` requested by \`${track.requestedBy.username} is played\``)
    }
}